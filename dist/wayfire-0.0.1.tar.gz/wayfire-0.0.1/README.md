#### Waypy serves as a python library, offering bindings specifically designed to interact with the wayfire compositor.

# [Use the wiki for more info](https://github.com/killown/waypy/wiki)
